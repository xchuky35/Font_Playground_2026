import React, { useEffect, useMemo, useRef, useState } from "react";
import builtinFonts from "./data/builtinFonts.json";

const LS_KEY = "font_playground_user_fonts_v1";
const LS_FAV = "font_playground_favs_v1";

/** base64 helpers */
function arrayBufferToBase64(buffer) {
  let binary = "";
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}
function base64ToArrayBuffer(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

function safeFontFamilyName(name) {
  return name.trim().replace(/\s+/g, " ");
}

function extToFormat(ext) {
  const e = ext.toLowerCase();
  if (e === "woff2") return "woff2";
  if (e === "woff") return "woff";
  return "truetype";
}

export default function App() {
  const [text, setText] = useState("Your Personalizations");
  const [search, setSearch] = useState("");
  const [onlyFav, setOnlyFav] = useState(false);

  const [fontSize, setFontSize] = useState(28);
  const [lineHeight, setLineHeight] = useState(1.2);
  const [letterSpacing, setLetterSpacing] = useState(0);

  const [userFonts, setUserFonts] = useState([]);
  const [favs, setFavs] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(LS_FAV) || "[]");
    } catch {
      return [];
    }
  });

  const [toast, setToast] = useState("");
  const toastTimer = useRef(null);

  function showToast(msg) {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(""), 1600);
  }

  // Persist favorites
  useEffect(() => {
    localStorage.setItem(LS_FAV, JSON.stringify(favs));
  }, [favs]);

  // Load user fonts from localStorage, inject @font-face for each
  useEffect(() => {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return;

      const loaded = [];
      for (const f of parsed) {
        if (!f?.name || !f?.base64 || !f?.format) continue;

        const arr = base64ToArrayBuffer(f.base64);
        const blob = new Blob([arr], { type: "font/" + f.format });
        const url = URL.createObjectURL(blob);

        injectFontFace(f.name, url, f.format);
        loaded.push({
          name: f.name,
          fallback: f.fallback || "sans-serif",
          tags: f.tags || ["user"],
          source: "user",
          format: f.format,
          url
        });
      }
      setUserFonts(loaded);
    } catch {
      // ignore
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Clean up object URLs on unmount
  useEffect(() => {
    return () => {
      userFonts.forEach((f) => {
        if (f.url) URL.revokeObjectURL(f.url);
      });
    };
  }, [userFonts]);

  function injectFontFace(name, url, format) {
    const fontName = safeFontFamilyName(name);
    const styleId = `user-font-${fontName.toLowerCase().replace(/\s/g, "-")}`;
    if (document.getElementById(styleId)) return;

    const style = document.createElement("style");
    style.id = styleId;
    style.textContent = `
@font-face{
  font-family:"${fontName}";
  src:url("${url}") format("${format}");
  font-display:swap;
}`;
    document.head.appendChild(style);
  }

  function toggleFav(fontName) {
    setFavs((prev) => {
      if (prev.includes(fontName)) return prev.filter((x) => x !== fontName);
      return [...prev, fontName];
    });
  }

  const allFonts = useMemo(() => {
    const built = builtinFonts.map((f) => ({ ...f, source: "builtin" }));
    return [...built, ...userFonts];
  }, [userFonts]);

  const filteredFonts = useMemo(() => {
    const q = search.trim().toLowerCase();
    return allFonts.filter((f) => {
      if (onlyFav && !favs.includes(f.name)) return false;
      if (!q) return true;
      const hay = `${f.name} ${(f.tags || []).join(" ")}`.toLowerCase();
      return hay.includes(q);
    });
  }, [allFonts, search, onlyFav, favs]);

  async function handleUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;

    const nameDefault = file.name.replace(/\.[^/.]+$/, "");
    const name = safeFontFamilyName(prompt("Font adı:", nameDefault) || "");
    if (!name) {
      showToast("Font adı gerekli.");
      return;
    }

    const ext = (file.name.split(".").pop() || "ttf").toLowerCase();
    if (!["ttf", "otf", "woff", "woff2"].includes(ext)) {
      showToast("Desteklenen: ttf / otf / woff / woff2");
      return;
    }

    const format = ext === "otf" ? "opentype" : extToFormat(ext);

    const buffer = await file.arrayBuffer();
    const base64 = arrayBufferToBase64(buffer);

    const blob = new Blob([buffer], { type: "font/" + format });
    const url = URL.createObjectURL(blob);
    injectFontFace(name, url, format);

    const newFont = {
      name,
      fallback: "sans-serif",
      tags: ["user"],
      source: "user",
      format,
      url
    };

    setUserFonts((prev) => [newFont, ...prev]);

    try {
      const prevRaw = localStorage.getItem(LS_KEY);
      const prevArr = prevRaw ? JSON.parse(prevRaw) : [];
      const toStore = Array.isArray(prevArr) ? prevArr : [];

      const filtered = toStore.filter((x) => x?.name !== name);
      filtered.unshift({ name, base64, format, fallback: "sans-serif", tags: ["user"] });

      localStorage.setItem(LS_KEY, JSON.stringify(filtered));
      showToast("Font eklendi ve kaydedildi.");
    } catch {
      showToast("Font eklendi (kalıcı kayıt başarısız).");
    } finally {
      e.target.value = "";
    }
  }

  function clearUserFonts() {
    userFonts.forEach((f) => {
      const styleId = `user-font-${f.name.toLowerCase().replace(/\s/g, "-")}`;
      const node = document.getElementById(styleId);
      if (node) node.remove();
      if (f.url) URL.revokeObjectURL(f.url);
    });

    setUserFonts([]);
    localStorage.removeItem(LS_KEY);
    showToast("Kullanıcı fontları temizlendi.");
  }

  function copyFontFamily(font) {
    const css = `font-family: "${font.name}", ${font.fallback || "sans-serif"};`;
    navigator.clipboard?.writeText(css);
    showToast("CSS kopyalandı.");
  }

  const statsText = `${filteredFonts.length} font • ${allFonts.length} toplam`;

  return (
    <div className="container">
      <div className="topbar">
        <div className="brand">
          <h1>Font Playground</h1>
          <p>Koyu mod, kül arka plan, ateş accent. Local fontlar + upload ile anlık preview.</p>
        </div>

        <div className="badge" title="Durum">
          <span className="dot" />
          <span>{statsText}</span>
        </div>
      </div>

      <div className="layout">
        <aside className="panel">
          <h2>KONTROL PANELİ</h2>

          <div className="field">
            <div className="label">Preview Metni</div>
            <input
              className="input"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Yaz ve anında tüm fontlarda gör…"
            />
          </div>

          <div className="field">
            <div className="label">Ara (font adı / tag)</div>
            <input
              className="input"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ör: tokyo, script, sans…"
            />
          </div>

          <div className="field">
            <div className="label">Filtreler</div>
            <div className="pillRow">
              <div className={`pill ${onlyFav ? "active" : ""}`} onClick={() => setOnlyFav((v) => !v)}>
                Sadece Favoriler
              </div>
              <div className="pill" onClick={() => setSearch("")}>
                Aramayı Temizle
              </div>
            </div>
          </div>

          <div className="hr" />

          <h2>TİPOGRAFİ</h2>

          <div className="field">
            <div className="label">Boyut (px)</div>
            <div className="rangeRow">
              <input
                className="range"
                type="range"
                min="14"
                max="70"
                value={fontSize}
                onChange={(e) => setFontSize(Number(e.target.value))}
              />
              <input
                className="input"
                value={fontSize}
                onChange={(e) => setFontSize(Number(e.target.value || 0))}
              />
            </div>
          </div>

          <div className="field">
            <div className="label">Satır Aralığı</div>
            <div className="rangeRow">
              <input
                className="range"
                type="range"
                min="1"
                max="2"
                step="0.05"
                value={lineHeight}
                onChange={(e) => setLineHeight(Number(e.target.value))}
              />
              <input
                className="input"
                value={lineHeight}
                onChange={(e) => setLineHeight(Number(e.target.value || 0))}
              />
            </div>
          </div>

          <div className="field">
            <div className="label">Harf Aralığı (px)</div>
            <div className="rangeRow">
              <input
                className="range"
                type="range"
                min="-1"
                max="6"
                step="0.25"
                value={letterSpacing}
                onChange={(e) => setLetterSpacing(Number(e.target.value))}
              />
              <input
                className="input"
                value={letterSpacing}
                onChange={(e) => setLetterSpacing(Number(e.target.value || 0))}
              />
            </div>
          </div>

          <div className="hr" />

          <h2>FONT EKLE (Mini SaaS)</h2>

          <div className="field">
            <div className="label">Dosya yükle (ttf/otf/woff/woff2)</div>
            <input className="input" type="file" accept=".ttf,.otf,.woff,.woff2" onChange={handleUpload} />
          </div>

          <button className="btn secondary" onClick={clearUserFonts}>
            Kullanıcı Fontlarını Temizle
          </button>
        </aside>

        <main>
          <div className="grid">
            {filteredFonts.map((font) => {
              const isFav = favs.includes(font.name);
              const family = `"${font.name}", ${font.fallback || "sans-serif"}`;
              return (
                <div className="card" key={`${font.source}-${font.name}`}>
                  <div className="cardHeader">
                    <div className="cardTitle">{font.name}</div>
                    <div className="actions">
                      <button
                        className={`iconBtn ${isFav ? "favOn" : ""}`}
                        onClick={() => toggleFav(font.name)}
                        title="Favori"
                      >
                        {isFav ? "★" : "☆"}
                      </button>
                      <button className="iconBtn" onClick={() => copyFontFamily(font)} title="Copy CSS">
                        CSS
                      </button>
                    </div>
                  </div>

                  <div
                    className="preview"
                    style={{
                      fontFamily: family,
                      fontSize: `${fontSize}px`,
                      lineHeight: lineHeight,
                      letterSpacing: `${letterSpacing}px`
                    }}
                  >
                    {text || " "}
                  </div>

                  <div className="meta">
                    <span>{font.source === "user" ? "user" : "local"}</span>
                    <span>{(font.tags || []).slice(0, 2).join(", ")}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </main>
      </div>

      {toast ? <div className="toast">{toast}</div> : null}
    </div>
  );
}
