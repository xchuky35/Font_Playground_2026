# Font Playground (React + Vite)

Koyu mod, kül arka plan ve ateş (fire) accent ile **font preview playground**.

## Özellikler
- Local fontlar (CSS `@font-face`) ile anlık preview
- Mini SaaS: Kullanıcı font dosyası upload eder, anında gridde görünür
- Favoriler (localStorage)
- Boyut / satır aralığı / harf aralığı kontrolleri
- 4'lü responsive grid, gölgeli kartlar

## Kurulum
```bash
npm install
npm run dev
```

## Local font ekleme
1. Font dosyalarını şuraya koy:
   `src/assets/fonts/`
2. `src/styles/fonts.css` içine `@font-face` ekle
3. `src/data/builtinFonts.json` içine font metadata ekle
